a: 

b: Best case of quick sort is omega(nlogn) Avg is theta(nlogn) and worst cae is theta (n^2)

best case for mergesort is omega(nlogn) Avg is theta(nlogn) and worst cae is theta (n^2)

best case for heapsort is omega(nlogn) Avg is theta(nlogn) and worst cae is theta (n^2)

c. as the length of the arrays increased so did the times of each of the arrays, i noticed that heapsort became slower compared to the other arays as the length of the other arrays increased passed 200000

d. 
average times : quicksort : 0.257134714
                randquick:0.243391105
		mergesort :0.219873843
		heapsort: 0.481439895


e.included in array doc

f. my shuffle routine was rather simple after creating an array of 1 to n values my shuffle for loop picked a random index j that is inbetween 1 to i and swaps until i hits 0. I found iut pretty straightforward and think it randomized the values rather well;

